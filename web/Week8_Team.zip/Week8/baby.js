var result = 0;  //baby steps learnyounode supplies numbers to test

  for (var i = 2; i < process.argv.length; i++){
    result += Number(process.argv[i]);
}
  console.log(result);


