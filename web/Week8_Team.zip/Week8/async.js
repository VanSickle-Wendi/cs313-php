var fs = require('fs');

fs.readFile(process.argv[2], function test(err, contents){
   if(err){
      console.log(err);
   }else {
      var newLines = contents.toString().split('\n').length-1; 
      console.log(newLines);
   }
});


