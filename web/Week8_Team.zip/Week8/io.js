var fs = require('fs');

var contents = fs.readFileSync(process.argv[2]);
var newLines = contents.toString().split('\n').length-1; //you can avoid .toString by passing 'utf8' as the 2nd argument to readFileSync
console.log(newLines);


